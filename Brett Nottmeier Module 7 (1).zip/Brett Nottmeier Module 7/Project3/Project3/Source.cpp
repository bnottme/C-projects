#include "GroceryApp.h"

int main() {
    GroceryApp grocer;
    grocer.run();
    return 0;
}